console.log("Just say Hi in the browser's JavaScript console");
