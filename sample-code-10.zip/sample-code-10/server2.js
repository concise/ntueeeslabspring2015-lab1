var http = require('http');

var PORT = 1234;
var HOST = '127.0.0.1';

var onrequest = function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.end('hello world');
};

var onlistening = function () {
  console.log('Server running at http://%s:%s/', HOST, PORT);
};

var server = http.createServer();
server.on('request', onrequest);
server.on('listening', onlistening);
server.listen(PORT, HOST);
