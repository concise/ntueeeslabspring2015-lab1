var http = require('http');

var PORT = 1234;
var HOST = '127.0.0.1';

var visitor_counter = 0;

var post_handler = function (req, res) {
  var uri = req.url;
  var data = '';
  req.on('data', function (chunk) {
    data += chunk;
  });
  req.on('end', function () {
    if (uri === '/echo') {
      res.end(data);
    } else {
      res.end('Unknown path');
    }
  });
};

var onrequest = function (req, res) {
  var http_requested_uri = req.url;


  if (req.method === 'POST') {
    return post_handler(req, res);
  }


  if (http_requested_uri === '/') {
    visitor_counter += 1;
  }

  if (http_requested_uri === '/counter') {
    res.write('Currently view counts: ' + visitor_counter);
    res.end();
    return;
  }

  var guess_filename = http_requested_uri.slice(1) || 'index.html';
  var buf = get_whitelisted_filecontent(guess_filename);
  if (buf === null) {
    res.writeHead(404, {'Content-Type': 'text/plain'});
    res.end('Not found\n');
  } else {
    res.end(buf);
  }
};

var onlistening = function () {
  console.log('Server running at http://%s:%s/', HOST, PORT);
};

var server = http.createServer();
server.on('request', onrequest);
server.on('listening', onlistening);
server.listen(PORT, HOST);



var get_whitelisted_filecontent = function (filename) {
  if (!in_whitelist(filename)) return null;
  return get_filecontent(filename);
};
var get_filecontent = function (filename) {
  var fs = require('fs');
  try {
    return fs.readFileSync('static/' + filename);
  } catch (e) {
    return null;
  }
};
var in_whitelist = function (name) { return whitelist.indexOf(name) !== -1; };
var whitelist = [ 'clientlogic.js', 'index.html', 'tuz1.png', 'tuz2.png', 'tuz3.png' ];
