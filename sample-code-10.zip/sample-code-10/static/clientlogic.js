console.log("Just say Hi in the browser's JavaScript console");

var get = function (uri, callback) {
  if (arguments.length !== 2) {
    throw new Error('Must provide two arguments');
  }
  var xhr = new XMLHttpRequest();
  xhr.open('GET', location.protocol + '//' + location.host + uri);
  xhr.onload = function () {
    callback.call(this, this.responseText);
  };
  xhr.send();
};

var post = function (uri, postdata, callback) {
  if (arguments.length !== 3) {
    throw new Error('Must provide three arguments');
  }
  var xhr = new XMLHttpRequest();
  xhr.open('POST', location.protocol + '//' + location.host + uri);
  xhr.onload = function () {
    callback.call(this, this.responseText);
  };
  xhr.send(postdata);
};
