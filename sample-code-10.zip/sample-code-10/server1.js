var http = require('http');

var PORT = 1234;
var HOST = '127.0.0.1';

http.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.end('hello world');
}).listen(PORT, HOST, function () {
  console.log('Server running at http://%s:%s/', HOST, PORT);
});
